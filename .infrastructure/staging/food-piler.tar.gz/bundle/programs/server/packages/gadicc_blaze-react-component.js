(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var blazeToReact, BlazeComponent;

var require = meteorInstall({"node_modules":{"meteor":{"gadicc:blaze-react-component":{"blaze-react-component-server.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////
//                                                                          //
// packages/gadicc_blaze-react-component/blaze-react-component-server.js    //
//                                                                          //
//////////////////////////////////////////////////////////////////////////////
                                                                            //
var _extends = require("@babel/runtime/helpers/builtin/extends");

module.export({
  blazeToReact: () => blazeToReact
});
let React, Component;
module.watch(require("react"), {
  default(v) {
    React = v;
  },

  Component(v) {
    Component = v;
  }

}, 0);
let ReactDOM;
module.watch(require("react-dom"), {
  default(v) {
    ReactDOM = v;
  }

}, 1);
let Blaze;
module.watch(require("meteor/blaze"), {
  Blaze(v) {
    Blaze = v;
  }

}, 2);
let ReactiveVar;
module.watch(require("meteor/reactive-var"), {
  ReactiveVar(v) {
    ReactiveVar = v;
  }

}, 3);

const BlazeComponent = props => {
  const html = {
    __html: Blaze.toHTMLWithData(props.template, _.omit(props, 'template'))
  };
  return React.createElement("span", {
    dangerouslySetInnerHTML: html
  });
};

module.runSetters(blazeToReact = function (template) {
  return props => React.createElement(BlazeComponent, _extends({}, props, {
    template: template
  }));
});
module.exportDefault(BlazeComponent);
//////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
var exports = require("/node_modules/meteor/gadicc:blaze-react-component/blaze-react-component-server.js");

/* Exports */
Package._define("gadicc:blaze-react-component", exports, {
  BlazeComponent: BlazeComponent,
  blazeToReact: blazeToReact
});

})();

//# sourceURL=meteor://💻app/packages/gadicc_blaze-react-component.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvZ2FkaWNjOmJsYXplLXJlYWN0LWNvbXBvbmVudC9ibGF6ZS1yZWFjdC1jb21wb25lbnQtc2VydmVyLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydCIsImJsYXplVG9SZWFjdCIsIlJlYWN0IiwiQ29tcG9uZW50Iiwid2F0Y2giLCJyZXF1aXJlIiwiZGVmYXVsdCIsInYiLCJSZWFjdERPTSIsIkJsYXplIiwiUmVhY3RpdmVWYXIiLCJCbGF6ZUNvbXBvbmVudCIsInByb3BzIiwiaHRtbCIsIl9faHRtbCIsInRvSFRNTFdpdGhEYXRhIiwidGVtcGxhdGUiLCJfIiwib21pdCIsImV4cG9ydERlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsT0FBT0MsTUFBUCxDQUFjO0FBQUNDLGdCQUFhLE1BQUlBO0FBQWxCLENBQWQ7QUFBK0MsSUFBSUMsS0FBSixFQUFVQyxTQUFWO0FBQW9CSixPQUFPSyxLQUFQLENBQWFDLFFBQVEsT0FBUixDQUFiLEVBQThCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDTCxZQUFNSyxDQUFOO0FBQVEsR0FBcEI7O0FBQXFCSixZQUFVSSxDQUFWLEVBQVk7QUFBQ0osZ0JBQVVJLENBQVY7QUFBWTs7QUFBOUMsQ0FBOUIsRUFBOEUsQ0FBOUU7QUFBaUYsSUFBSUMsUUFBSjtBQUFhVCxPQUFPSyxLQUFQLENBQWFDLFFBQVEsV0FBUixDQUFiLEVBQWtDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDQyxlQUFTRCxDQUFUO0FBQVc7O0FBQXZCLENBQWxDLEVBQTJELENBQTNEO0FBQThELElBQUlFLEtBQUo7QUFBVVYsT0FBT0ssS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDSSxRQUFNRixDQUFOLEVBQVE7QUFBQ0UsWUFBTUYsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJRyxXQUFKO0FBQWdCWCxPQUFPSyxLQUFQLENBQWFDLFFBQVEscUJBQVIsQ0FBYixFQUE0QztBQUFDSyxjQUFZSCxDQUFaLEVBQWM7QUFBQ0csa0JBQVlILENBQVo7QUFBYzs7QUFBOUIsQ0FBNUMsRUFBNEUsQ0FBNUU7O0FBS3JULE1BQU1JLGlCQUFrQkMsS0FBRCxJQUFXO0FBQ2hDLFFBQU1DLE9BQU87QUFDWEMsWUFBUUwsTUFBTU0sY0FBTixDQUNOSCxNQUFNSSxRQURBLEVBRU5DLEVBQUVDLElBQUYsQ0FBT04sS0FBUCxFQUFjLFVBQWQsQ0FGTTtBQURHLEdBQWI7QUFPQSxTQUFTO0FBQU0sNkJBQXlCQztBQUEvQixJQUFUO0FBQ0QsQ0FURDs7QUFXQSxpQ0FBZSxVQUFTRyxRQUFULEVBQW1CO0FBQ2hDLFNBQVFKLEtBQUQsSUFBVyxvQkFBQyxjQUFELGVBQW9CQSxLQUFwQjtBQUEyQixjQUFVSTtBQUFyQyxLQUFsQjtBQUNELENBRkQ7QUFoQkFqQixPQUFPb0IsYUFBUCxDQXFCZVIsY0FyQmYsRSIsImZpbGUiOiIvcGFja2FnZXMvZ2FkaWNjX2JsYXplLXJlYWN0LWNvbXBvbmVudC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgUmVhY3RET00gZnJvbSAncmVhY3QtZG9tJztcbmltcG9ydCB7IEJsYXplIH0gZnJvbSAnbWV0ZW9yL2JsYXplJztcbmltcG9ydCB7IFJlYWN0aXZlVmFyIH0gZnJvbSAnbWV0ZW9yL3JlYWN0aXZlLXZhcic7XG5cbmNvbnN0IEJsYXplQ29tcG9uZW50ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IGh0bWwgPSB7XG4gICAgX19odG1sOiBCbGF6ZS50b0hUTUxXaXRoRGF0YShcbiAgICAgIHByb3BzLnRlbXBsYXRlLFxuICAgICAgXy5vbWl0KHByb3BzLCAndGVtcGxhdGUnKVxuICAgKVxuICB9O1xuXG4gIHJldHVybiAoIDxzcGFuIGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MPXtodG1sfSAvPiApO1xufVxuXG5ibGF6ZVRvUmVhY3QgPSBmdW5jdGlvbih0ZW1wbGF0ZSkge1xuICByZXR1cm4gKHByb3BzKSA9PiA8QmxhemVDb21wb25lbnQgey4uLnByb3BzfSB0ZW1wbGF0ZT17dGVtcGxhdGV9IC8+O1xufVxuXG5leHBvcnQgeyBibGF6ZVRvUmVhY3QgfTtcbmV4cG9ydCBkZWZhdWx0IEJsYXplQ29tcG9uZW50O1xuIl19
