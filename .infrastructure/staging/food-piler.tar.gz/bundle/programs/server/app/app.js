var require = meteorInstall({"imports":{"api":{"ingredients.jsx":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// imports/api/ingredients.jsx                                                                                  //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
module.export({
  Ingredients: () => Ingredients
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let check;
module.watch(require("meteor/check"), {
  check(v) {
    check = v;
  }

}, 2);
const Ingredients = new Mongo.Collection('ingredients');

if (Meteor.isServer) {
  Meteor.publish('adminIngredients', function adminIngredientsPublication() {
    return Ingredients.find({
      ownerId: this.userId
    });
  });
  Meteor.publish('ingredients', function ingredientsPublication() {
    return Ingredients.find();
  });
}

Meteor.methods({
  'ingredients.toggleCheck'(ingredientId, checkboxName, newCheckboxState) {
    check(ingredientId, String);
    check(checkboxName, String);
    check(newCheckboxState, Boolean);
    ingrForUserCheck = Ingredients.findOne(ingredientId);

    if (Meteor.userId() == null || Meteor.userId() != ingrForUserCheck.ownerId) {
      throw new Meteor.Error('not-authorized');
    }

    Ingredients.update(ingredientId, {
      $set: {
        // because we need to use the var checkboxName, and not the string 'checkboxName', use []
        [checkboxName]: newCheckboxState
      }
    });
  },

  'ingredients.submitIngrText'(ingredientId, ingrName, ingrDesc, ingrFlex) {
    check(ingredientId, String);
    check(ingrName, String);
    check(ingrDesc, String);
    check(ingrFlex, String);
    ingrForUserCheck = Ingredients.findOne(ingredientId);

    if (Meteor.userId() == null || Meteor.userId() != ingrForUserCheck.ownerId) {
      throw new Meteor.Error('not-authorized');
    }

    Ingredients.update(ingredientId, {
      $set: {
        ingrName: ingrName,
        ingrDesc: ingrDesc,
        ingrFlex: ingrFlex,
        editing: false
      }
    });
  },

  'ingredients.deleteIngr'(ingredientId) {
    check(ingredientId, String);
    ingrForUserCheck = Ingredients.findOne(ingredientId);

    if (Meteor.userId() == null || Meteor.userId() != ingrForUserCheck.ownerId) {
      throw new Meteor.Error('not-authorized');
    }

    Ingredients.remove(ingredientId);
  },

  'ingredients.toggleEditIngr'(ingredientId, editingState) {
    check(ingredientId, String);
    check(editingState, Boolean);
    ingrForUserCheck = Ingredients.findOne(ingredientId);

    if (Meteor.userId() == null || Meteor.userId() != ingrForUserCheck.ownerId) {
      throw new Meteor.Error('not-authorized');
    }

    Ingredients.update(ingredientId, {
      $set: {
        editing: editingState
      }
    });
  },

  // note that "admin" must be hard coded here since there is no guarantee that a previous ingredient
  // that is owned by admin exists, so no check can be used by polling the mongo db for an existing username/id
  'ingredients.addNewBlankIngredient'() {
    if (Meteor.user() == null || Meteor.user().username != "admin") {
      throw new Meteor.Error('not-authorized');
    }

    Ingredients.insert({
      ingrName: '',
      ingrDesc: '',
      ingrFlex: '',
      isBase: false,
      isFiller: false,
      isTopping: false,
      isVeggie: false,
      isVegan: false,
      isGF: false,
      isDF: false,
      isEF: false,
      isPesc: false,
      editing: true,
      ownerId: Meteor.userId(),
      username: Meteor.user().username,
      createdAt: new Date()
    });
  },

  'ingredients.insertImportedData'(i) {
    if (Meteor.user() == null || Meteor.user().username != "admin") {
      throw new Meteor.Error('not-authorized');
    }

    existingIngr = Ingredients.findOne(i.ingrName);
    Ingredients.insert({
      ingrName: i.ingrName,
      ingrDesc: i.ingrDesc,
      ingrFlex: i.ingrFlex,
      isBase: i.isBase.toLowerCase() == 'true',
      isFiller: i.isFiller.toLowerCase() == 'true',
      isTopping: i.isTopping.toLowerCase() == 'true',
      isVeggie: i.isVeggie.toLowerCase() == 'true',
      isVegan: i.isVegan.toLowerCase() == 'true',
      isGF: i.isGF.toLowerCase() == 'true',
      isDF: i.isDF.toLowerCase() == 'true',
      isEF: i.isEF.toLowerCase() == 'true',
      isPesc: i.isPesc.toLowerCase() == 'true',
      editing: false,
      ownerId: Meteor.userId(),
      username: Meteor.user().username,
      createdAt: new Date()
    });
  }

});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.jsx":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// server/main.jsx                                                                                              //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
module.watch(require("../imports/api/ingredients.jsx"));
Meteor.startup(() => {// code to run on server at startup
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx"
  ]
});
require("/server/main.jsx");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvaW5ncmVkaWVudHMuanN4IiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qc3giXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiSW5ncmVkaWVudHMiLCJNb25nbyIsIndhdGNoIiwicmVxdWlyZSIsInYiLCJNZXRlb3IiLCJjaGVjayIsIkNvbGxlY3Rpb24iLCJpc1NlcnZlciIsInB1Ymxpc2giLCJhZG1pbkluZ3JlZGllbnRzUHVibGljYXRpb24iLCJmaW5kIiwib3duZXJJZCIsInVzZXJJZCIsImluZ3JlZGllbnRzUHVibGljYXRpb24iLCJtZXRob2RzIiwiaW5ncmVkaWVudElkIiwiY2hlY2tib3hOYW1lIiwibmV3Q2hlY2tib3hTdGF0ZSIsIlN0cmluZyIsIkJvb2xlYW4iLCJpbmdyRm9yVXNlckNoZWNrIiwiZmluZE9uZSIsIkVycm9yIiwidXBkYXRlIiwiJHNldCIsImluZ3JOYW1lIiwiaW5nckRlc2MiLCJpbmdyRmxleCIsImVkaXRpbmciLCJyZW1vdmUiLCJlZGl0aW5nU3RhdGUiLCJ1c2VyIiwidXNlcm5hbWUiLCJpbnNlcnQiLCJpc0Jhc2UiLCJpc0ZpbGxlciIsImlzVG9wcGluZyIsImlzVmVnZ2llIiwiaXNWZWdhbiIsImlzR0YiLCJpc0RGIiwiaXNFRiIsImlzUGVzYyIsImNyZWF0ZWRBdCIsIkRhdGUiLCJpIiwiZXhpc3RpbmdJbmdyIiwidG9Mb3dlckNhc2UiLCJzdGFydHVwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBQSxPQUFPQyxNQUFQLENBQWM7QUFBQ0MsZUFBWSxNQUFJQTtBQUFqQixDQUFkO0FBQTZDLElBQUlDLEtBQUo7QUFBVUgsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRixRQUFNRyxDQUFOLEVBQVE7QUFBQ0gsWUFBTUcsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJQyxNQUFKO0FBQVdQLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0UsU0FBT0QsQ0FBUCxFQUFTO0FBQUNDLGFBQU9ELENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUUsS0FBSjtBQUFVUixPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNHLFFBQU1GLENBQU4sRUFBUTtBQUFDRSxZQUFNRixDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBSWhNLE1BQU1KLGNBQWMsSUFBSUMsTUFBTU0sVUFBVixDQUFxQixhQUFyQixDQUFwQjs7QUFFUCxJQUFHRixPQUFPRyxRQUFWLEVBQW9CO0FBQ25CSCxTQUFPSSxPQUFQLENBQWUsa0JBQWYsRUFBbUMsU0FBU0MsMkJBQVQsR0FBdUM7QUFDekUsV0FBT1YsWUFBWVcsSUFBWixDQUFpQjtBQUFDQyxlQUFTLEtBQUtDO0FBQWYsS0FBakIsQ0FBUDtBQUNBLEdBRkQ7QUFJQVIsU0FBT0ksT0FBUCxDQUFlLGFBQWYsRUFBOEIsU0FBU0ssc0JBQVQsR0FBa0M7QUFDL0QsV0FBT2QsWUFBWVcsSUFBWixFQUFQO0FBQ0EsR0FGRDtBQUdBOztBQUVETixPQUFPVSxPQUFQLENBQWU7QUFDZCw0QkFBMEJDLFlBQTFCLEVBQXdDQyxZQUF4QyxFQUFzREMsZ0JBQXRELEVBQXdFO0FBQ3ZFWixVQUFNVSxZQUFOLEVBQW9CRyxNQUFwQjtBQUNBYixVQUFNVyxZQUFOLEVBQW9CRSxNQUFwQjtBQUNBYixVQUFNWSxnQkFBTixFQUF3QkUsT0FBeEI7QUFFQUMsdUJBQW1CckIsWUFBWXNCLE9BQVosQ0FBb0JOLFlBQXBCLENBQW5COztBQUNBLFFBQUdYLE9BQU9RLE1BQVAsTUFBbUIsSUFBbkIsSUFBMkJSLE9BQU9RLE1BQVAsTUFBbUJRLGlCQUFpQlQsT0FBbEUsRUFBMkU7QUFDMUUsWUFBTSxJQUFJUCxPQUFPa0IsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNBOztBQUVEdkIsZ0JBQVl3QixNQUFaLENBQW1CUixZQUFuQixFQUFpQztBQUNoQ1MsWUFBTTtBQUNMO0FBQ0EsU0FBQ1IsWUFBRCxHQUFnQkM7QUFGWDtBQUQwQixLQUFqQztBQU1BLEdBakJhOztBQWtCZCwrQkFBNkJGLFlBQTdCLEVBQTJDVSxRQUEzQyxFQUFxREMsUUFBckQsRUFBK0RDLFFBQS9ELEVBQXlFO0FBQ3hFdEIsVUFBTVUsWUFBTixFQUFvQkcsTUFBcEI7QUFDQWIsVUFBTW9CLFFBQU4sRUFBZ0JQLE1BQWhCO0FBQ0FiLFVBQU1xQixRQUFOLEVBQWdCUixNQUFoQjtBQUNBYixVQUFNc0IsUUFBTixFQUFnQlQsTUFBaEI7QUFFQUUsdUJBQW1CckIsWUFBWXNCLE9BQVosQ0FBb0JOLFlBQXBCLENBQW5COztBQUNBLFFBQUdYLE9BQU9RLE1BQVAsTUFBbUIsSUFBbkIsSUFBMkJSLE9BQU9RLE1BQVAsTUFBbUJRLGlCQUFpQlQsT0FBbEUsRUFBMkU7QUFDMUUsWUFBTSxJQUFJUCxPQUFPa0IsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNBOztBQUVEdkIsZ0JBQVl3QixNQUFaLENBQW1CUixZQUFuQixFQUFpQztBQUNoQ1MsWUFBTTtBQUNMQyxrQkFBVUEsUUFETDtBQUVMQyxrQkFBVUEsUUFGTDtBQUdMQyxrQkFBVUEsUUFITDtBQUlMQyxpQkFBUztBQUpKO0FBRDBCLEtBQWpDO0FBUUEsR0FyQ2E7O0FBc0NkLDJCQUF5QmIsWUFBekIsRUFBdUM7QUFDdENWLFVBQU1VLFlBQU4sRUFBb0JHLE1BQXBCO0FBRUFFLHVCQUFtQnJCLFlBQVlzQixPQUFaLENBQW9CTixZQUFwQixDQUFuQjs7QUFDQSxRQUFHWCxPQUFPUSxNQUFQLE1BQW1CLElBQW5CLElBQTJCUixPQUFPUSxNQUFQLE1BQW1CUSxpQkFBaUJULE9BQWxFLEVBQTJFO0FBQzFFLFlBQU0sSUFBSVAsT0FBT2tCLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDQTs7QUFFRHZCLGdCQUFZOEIsTUFBWixDQUFtQmQsWUFBbkI7QUFDQSxHQS9DYTs7QUFnRGQsK0JBQTZCQSxZQUE3QixFQUEyQ2UsWUFBM0MsRUFBeUQ7QUFDeER6QixVQUFNVSxZQUFOLEVBQW9CRyxNQUFwQjtBQUNBYixVQUFNeUIsWUFBTixFQUFvQlgsT0FBcEI7QUFFQUMsdUJBQW1CckIsWUFBWXNCLE9BQVosQ0FBb0JOLFlBQXBCLENBQW5COztBQUNBLFFBQUdYLE9BQU9RLE1BQVAsTUFBbUIsSUFBbkIsSUFBMkJSLE9BQU9RLE1BQVAsTUFBbUJRLGlCQUFpQlQsT0FBbEUsRUFBMkU7QUFDMUUsWUFBTSxJQUFJUCxPQUFPa0IsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNBOztBQUVEdkIsZ0JBQVl3QixNQUFaLENBQW1CUixZQUFuQixFQUFpQztBQUNoQ1MsWUFBTTtBQUNMSSxpQkFBU0U7QUFESjtBQUQwQixLQUFqQztBQUtBLEdBOURhOztBQWdFZDtBQUNBO0FBQ0Esd0NBQXNDO0FBQ3JDLFFBQUcxQixPQUFPMkIsSUFBUCxNQUFpQixJQUFqQixJQUF5QjNCLE9BQU8yQixJQUFQLEdBQWNDLFFBQWQsSUFBMEIsT0FBdEQsRUFBK0Q7QUFDOUQsWUFBTSxJQUFJNUIsT0FBT2tCLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDQTs7QUFDRHZCLGdCQUFZa0MsTUFBWixDQUFtQjtBQUNsQlIsZ0JBQVUsRUFEUTtBQUVsQkMsZ0JBQVUsRUFGUTtBQUdsQkMsZ0JBQVUsRUFIUTtBQUlsQk8sY0FBUSxLQUpVO0FBS2xCQyxnQkFBVSxLQUxRO0FBTWxCQyxpQkFBVyxLQU5PO0FBT2xCQyxnQkFBVSxLQVBRO0FBUWxCQyxlQUFTLEtBUlM7QUFTbEJDLFlBQU0sS0FUWTtBQVVsQkMsWUFBTSxLQVZZO0FBV2xCQyxZQUFNLEtBWFk7QUFZbEJDLGNBQVEsS0FaVTtBQWFsQmQsZUFBUyxJQWJTO0FBY2xCakIsZUFBU1AsT0FBT1EsTUFBUCxFQWRTO0FBZWxCb0IsZ0JBQVU1QixPQUFPMkIsSUFBUCxHQUFjQyxRQWZOO0FBZ0JsQlcsaUJBQVcsSUFBSUMsSUFBSjtBQWhCTyxLQUFuQjtBQWtCQSxHQXhGYTs7QUEwRmQsbUNBQWlDQyxDQUFqQyxFQUFvQztBQUNuQyxRQUFHekMsT0FBTzJCLElBQVAsTUFBaUIsSUFBakIsSUFBeUIzQixPQUFPMkIsSUFBUCxHQUFjQyxRQUFkLElBQTBCLE9BQXRELEVBQStEO0FBQzlELFlBQU0sSUFBSTVCLE9BQU9rQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0E7O0FBRUR3QixtQkFBZS9DLFlBQVlzQixPQUFaLENBQW9Cd0IsRUFBRXBCLFFBQXRCLENBQWY7QUFDQTFCLGdCQUFZa0MsTUFBWixDQUFtQjtBQUNsQlIsZ0JBQVVvQixFQUFFcEIsUUFETTtBQUVsQkMsZ0JBQVVtQixFQUFFbkIsUUFGTTtBQUdsQkMsZ0JBQVVrQixFQUFFbEIsUUFITTtBQUlsQk8sY0FBU1csRUFBRVgsTUFBRixDQUFTYSxXQUFULE1BQTBCLE1BSmpCO0FBS2xCWixnQkFBV1UsRUFBRVYsUUFBRixDQUFXWSxXQUFYLE1BQTRCLE1BTHJCO0FBTWxCWCxpQkFBWVMsRUFBRVQsU0FBRixDQUFZVyxXQUFaLE1BQTZCLE1BTnZCO0FBT2xCVixnQkFBV1EsRUFBRVIsUUFBRixDQUFXVSxXQUFYLE1BQTRCLE1BUHJCO0FBUWxCVCxlQUFVTyxFQUFFUCxPQUFGLENBQVVTLFdBQVYsTUFBMkIsTUFSbkI7QUFTbEJSLFlBQU9NLEVBQUVOLElBQUYsQ0FBT1EsV0FBUCxNQUF3QixNQVRiO0FBVWxCUCxZQUFPSyxFQUFFTCxJQUFGLENBQU9PLFdBQVAsTUFBd0IsTUFWYjtBQVdsQk4sWUFBT0ksRUFBRUosSUFBRixDQUFPTSxXQUFQLE1BQXdCLE1BWGI7QUFZbEJMLGNBQVNHLEVBQUVILE1BQUYsQ0FBU0ssV0FBVCxNQUEwQixNQVpqQjtBQWFsQm5CLGVBQVMsS0FiUztBQWNsQmpCLGVBQVNQLE9BQU9RLE1BQVAsRUFkUztBQWVsQm9CLGdCQUFVNUIsT0FBTzJCLElBQVAsR0FBY0MsUUFmTjtBQWdCbEJXLGlCQUFXLElBQUlDLElBQUo7QUFoQk8sS0FBbkI7QUFrQkE7O0FBbEhhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNoQkEsSUFBSXhDLE1BQUo7QUFBV1AsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRSxTQUFPRCxDQUFQLEVBQVM7QUFBQ0MsYUFBT0QsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRE4sT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGdDQUFSLENBQWI7QUFHMUVFLE9BQU80QyxPQUFQLENBQWUsTUFBTSxDQUNwQjtBQUNBLENBRkQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG4gXG5leHBvcnQgY29uc3QgSW5ncmVkaWVudHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignaW5ncmVkaWVudHMnKTtcblxuaWYoTWV0ZW9yLmlzU2VydmVyKSB7XG5cdE1ldGVvci5wdWJsaXNoKCdhZG1pbkluZ3JlZGllbnRzJywgZnVuY3Rpb24gYWRtaW5JbmdyZWRpZW50c1B1YmxpY2F0aW9uKCkge1xuXHRcdHJldHVybiBJbmdyZWRpZW50cy5maW5kKHtvd25lcklkOiB0aGlzLnVzZXJJZH0pO1xuXHR9KVxuXG5cdE1ldGVvci5wdWJsaXNoKCdpbmdyZWRpZW50cycsIGZ1bmN0aW9uIGluZ3JlZGllbnRzUHVibGljYXRpb24oKSB7XG5cdFx0cmV0dXJuIEluZ3JlZGllbnRzLmZpbmQoKTtcblx0fSlcbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuXHQnaW5ncmVkaWVudHMudG9nZ2xlQ2hlY2snKGluZ3JlZGllbnRJZCwgY2hlY2tib3hOYW1lLCBuZXdDaGVja2JveFN0YXRlKSB7XG5cdFx0Y2hlY2soaW5ncmVkaWVudElkLCBTdHJpbmcpO1xuXHRcdGNoZWNrKGNoZWNrYm94TmFtZSwgU3RyaW5nKTtcblx0XHRjaGVjayhuZXdDaGVja2JveFN0YXRlLCBCb29sZWFuKTtcblxuXHRcdGluZ3JGb3JVc2VyQ2hlY2sgPSBJbmdyZWRpZW50cy5maW5kT25lKGluZ3JlZGllbnRJZCk7XG5cdFx0aWYoTWV0ZW9yLnVzZXJJZCgpID09IG51bGwgfHwgTWV0ZW9yLnVzZXJJZCgpICE9IGluZ3JGb3JVc2VyQ2hlY2sub3duZXJJZCkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcblx0XHR9XG5cblx0XHRJbmdyZWRpZW50cy51cGRhdGUoaW5ncmVkaWVudElkLCB7XG5cdFx0XHQkc2V0OiB7XG5cdFx0XHRcdC8vIGJlY2F1c2Ugd2UgbmVlZCB0byB1c2UgdGhlIHZhciBjaGVja2JveE5hbWUsIGFuZCBub3QgdGhlIHN0cmluZyAnY2hlY2tib3hOYW1lJywgdXNlIFtdXG5cdFx0XHRcdFtjaGVja2JveE5hbWVdOiBuZXdDaGVja2JveFN0YXRlLFxuXHRcdFx0fVxuXHRcdH0pO1xuXHR9LFxuXHQnaW5ncmVkaWVudHMuc3VibWl0SW5nclRleHQnKGluZ3JlZGllbnRJZCwgaW5nck5hbWUsIGluZ3JEZXNjLCBpbmdyRmxleCkge1xuXHRcdGNoZWNrKGluZ3JlZGllbnRJZCwgU3RyaW5nKTtcblx0XHRjaGVjayhpbmdyTmFtZSwgU3RyaW5nKTtcblx0XHRjaGVjayhpbmdyRGVzYywgU3RyaW5nKTtcblx0XHRjaGVjayhpbmdyRmxleCwgU3RyaW5nKTtcblxuXHRcdGluZ3JGb3JVc2VyQ2hlY2sgPSBJbmdyZWRpZW50cy5maW5kT25lKGluZ3JlZGllbnRJZCk7XG5cdFx0aWYoTWV0ZW9yLnVzZXJJZCgpID09IG51bGwgfHwgTWV0ZW9yLnVzZXJJZCgpICE9IGluZ3JGb3JVc2VyQ2hlY2sub3duZXJJZCkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcblx0XHR9XG5cblx0XHRJbmdyZWRpZW50cy51cGRhdGUoaW5ncmVkaWVudElkLCB7XG5cdFx0XHQkc2V0OiB7XG5cdFx0XHRcdGluZ3JOYW1lOiBpbmdyTmFtZSxcblx0XHRcdFx0aW5nckRlc2M6IGluZ3JEZXNjLFxuXHRcdFx0XHRpbmdyRmxleDogaW5nckZsZXgsXG5cdFx0XHRcdGVkaXRpbmc6IGZhbHNlLFxuXHRcdFx0fVxuXHRcdH0pO1xuXHR9LFxuXHQnaW5ncmVkaWVudHMuZGVsZXRlSW5ncicoaW5ncmVkaWVudElkKSB7XG5cdFx0Y2hlY2soaW5ncmVkaWVudElkLCBTdHJpbmcpO1xuXG5cdFx0aW5nckZvclVzZXJDaGVjayA9IEluZ3JlZGllbnRzLmZpbmRPbmUoaW5ncmVkaWVudElkKTtcblx0XHRpZihNZXRlb3IudXNlcklkKCkgPT0gbnVsbCB8fCBNZXRlb3IudXNlcklkKCkgIT0gaW5nckZvclVzZXJDaGVjay5vd25lcklkKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuXHRcdH1cblxuXHRcdEluZ3JlZGllbnRzLnJlbW92ZShpbmdyZWRpZW50SWQpO1xuXHR9LFxuXHQnaW5ncmVkaWVudHMudG9nZ2xlRWRpdEluZ3InKGluZ3JlZGllbnRJZCwgZWRpdGluZ1N0YXRlKSB7XG5cdFx0Y2hlY2soaW5ncmVkaWVudElkLCBTdHJpbmcpO1xuXHRcdGNoZWNrKGVkaXRpbmdTdGF0ZSwgQm9vbGVhbik7XG5cblx0XHRpbmdyRm9yVXNlckNoZWNrID0gSW5ncmVkaWVudHMuZmluZE9uZShpbmdyZWRpZW50SWQpO1xuXHRcdGlmKE1ldGVvci51c2VySWQoKSA9PSBudWxsIHx8IE1ldGVvci51c2VySWQoKSAhPSBpbmdyRm9yVXNlckNoZWNrLm93bmVySWQpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG5cdFx0fVxuXG5cdFx0SW5ncmVkaWVudHMudXBkYXRlKGluZ3JlZGllbnRJZCwge1x0XG5cdFx0XHQkc2V0OiB7XG5cdFx0XHRcdGVkaXRpbmc6IGVkaXRpbmdTdGF0ZSxcblx0XHRcdH1cblx0XHR9KTtcblx0fSxcblxuXHQvLyBub3RlIHRoYXQgXCJhZG1pblwiIG11c3QgYmUgaGFyZCBjb2RlZCBoZXJlIHNpbmNlIHRoZXJlIGlzIG5vIGd1YXJhbnRlZSB0aGF0IGEgcHJldmlvdXMgaW5ncmVkaWVudFxuXHQvLyB0aGF0IGlzIG93bmVkIGJ5IGFkbWluIGV4aXN0cywgc28gbm8gY2hlY2sgY2FuIGJlIHVzZWQgYnkgcG9sbGluZyB0aGUgbW9uZ28gZGIgZm9yIGFuIGV4aXN0aW5nIHVzZXJuYW1lL2lkXG5cdCdpbmdyZWRpZW50cy5hZGROZXdCbGFua0luZ3JlZGllbnQnKCkge1xuXHRcdGlmKE1ldGVvci51c2VyKCkgPT0gbnVsbCB8fCBNZXRlb3IudXNlcigpLnVzZXJuYW1lICE9IFwiYWRtaW5cIikge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcblx0XHR9XG5cdFx0SW5ncmVkaWVudHMuaW5zZXJ0KHtcblx0XHRcdGluZ3JOYW1lOiAnJyxcblx0XHRcdGluZ3JEZXNjOiAnJyxcblx0XHRcdGluZ3JGbGV4OiAnJyxcblx0XHRcdGlzQmFzZTogZmFsc2UsXG5cdFx0XHRpc0ZpbGxlcjogZmFsc2UsXG5cdFx0XHRpc1RvcHBpbmc6IGZhbHNlLFxuXHRcdFx0aXNWZWdnaWU6IGZhbHNlLFxuXHRcdFx0aXNWZWdhbjogZmFsc2UsXG5cdFx0XHRpc0dGOiBmYWxzZSxcblx0XHRcdGlzREY6IGZhbHNlLFxuXHRcdFx0aXNFRjogZmFsc2UsXG5cdFx0XHRpc1Blc2M6IGZhbHNlLFxuXHRcdFx0ZWRpdGluZzogdHJ1ZSxcblx0XHRcdG93bmVySWQ6IE1ldGVvci51c2VySWQoKSxcblx0XHRcdHVzZXJuYW1lOiBNZXRlb3IudXNlcigpLnVzZXJuYW1lLFxuXHRcdFx0Y3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxuXHRcdH0pO1xuXHR9LFxuXG5cdCdpbmdyZWRpZW50cy5pbnNlcnRJbXBvcnRlZERhdGEnKGkpIHtcblx0XHRpZihNZXRlb3IudXNlcigpID09IG51bGwgfHwgTWV0ZW9yLnVzZXIoKS51c2VybmFtZSAhPSBcImFkbWluXCIpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1hdXRob3JpemVkJyk7XG5cdFx0fVxuXG5cdFx0ZXhpc3RpbmdJbmdyID0gSW5ncmVkaWVudHMuZmluZE9uZShpLmluZ3JOYW1lKTtcblx0XHRJbmdyZWRpZW50cy5pbnNlcnQoe1xuXHRcdFx0aW5nck5hbWU6IGkuaW5nck5hbWUsXG5cdFx0XHRpbmdyRGVzYzogaS5pbmdyRGVzYyxcblx0XHRcdGluZ3JGbGV4OiBpLmluZ3JGbGV4LFxuXHRcdFx0aXNCYXNlOiAoaS5pc0Jhc2UudG9Mb3dlckNhc2UoKSA9PSAndHJ1ZScpLFxuXHRcdFx0aXNGaWxsZXI6IChpLmlzRmlsbGVyLnRvTG93ZXJDYXNlKCkgPT0gJ3RydWUnKSxcblx0XHRcdGlzVG9wcGluZzogKGkuaXNUb3BwaW5nLnRvTG93ZXJDYXNlKCkgPT0gJ3RydWUnKSxcblx0XHRcdGlzVmVnZ2llOiAoaS5pc1ZlZ2dpZS50b0xvd2VyQ2FzZSgpID09ICd0cnVlJyksXG5cdFx0XHRpc1ZlZ2FuOiAoaS5pc1ZlZ2FuLnRvTG93ZXJDYXNlKCkgPT0gJ3RydWUnKSxcblx0XHRcdGlzR0Y6IChpLmlzR0YudG9Mb3dlckNhc2UoKSA9PSAndHJ1ZScpLFxuXHRcdFx0aXNERjogKGkuaXNERi50b0xvd2VyQ2FzZSgpID09ICd0cnVlJyksXG5cdFx0XHRpc0VGOiAoaS5pc0VGLnRvTG93ZXJDYXNlKCkgPT0gJ3RydWUnKSxcblx0XHRcdGlzUGVzYzogKGkuaXNQZXNjLnRvTG93ZXJDYXNlKCkgPT0gJ3RydWUnKSxcblx0XHRcdGVkaXRpbmc6IGZhbHNlLFxuXHRcdFx0b3duZXJJZDogTWV0ZW9yLnVzZXJJZCgpLFxuXHRcdFx0dXNlcm5hbWU6IE1ldGVvci51c2VyKCkudXNlcm5hbWUsXG5cdFx0XHRjcmVhdGVkQXQ6IG5ldyBEYXRlKCksXG5cdFx0fSk7XG5cdH1cbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgJy4uL2ltcG9ydHMvYXBpL2luZ3JlZGllbnRzLmpzeCc7XG5cbk1ldGVvci5zdGFydHVwKCgpID0+IHtcblx0Ly8gY29kZSB0byBydW4gb24gc2VydmVyIGF0IHN0YXJ0dXBcbn0pO1xuIl19
